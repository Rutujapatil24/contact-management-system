#[warn(unused_parens)]
use std::collections::HashMap;
use std::io;
use regex::Regex;
use std::convert::TryInto;
fn main() {
	let mut n=String::new();
	let mut name=String::new();
	let mut no=String::new();
    let mut email=String::new();
	let mut adress=String::new();
	let mut srno=String::new();
	
	let mut v_name:Vec<String>=Vec::new();
	let mut v_no:Vec<String>=Vec::new();
    let mut v_email:Vec<String>=Vec::new();
	let mut v_adress:Vec<String>=Vec::new();
	let mut v_srno:Vec<String>=Vec::new();
	
	let mut c=1;
	let mut choice=String::new();
    let mut re=String::new();
   println!("How many contact you want to store.....................");

	io::stdin().read_line(&mut n).expect("Fail");
	let n:u32=n.trim().parse().expect("Fail");
	
	while c<=n
    {
	    srno.clear();
		name.clear();
		no.clear();
        email.clear();
		adress.clear();
		
		println!("Serial number ,Enter name,contact no,email,adress:\n");
		
		println!("Serial number:");
		io::stdin().read_line(&mut srno).expect("Fail");
		let srno:String=srno.trim().parse().expect("Failed");
		
		
        println!("Enter name:");
		io::stdin().read_line(&mut name).expect("Fail");
		let name:String=name.trim().parse().expect("Failed");
		
		println!("Enter contact number:");
        io::stdin().read_line(&mut no).expect("Fail");
		let no:String=no.trim().parse().expect("Failed");
		if no.len()==10
        {
      
        }
        else
        {
        println!("number is not valid");
		break;
        }
		 if v_no.contains(&no)
	     {
	     println!("contact number already exist");
		 break;
	     }
	    else
	     {

		
        println!("Enter email:");
        let domain_regex = Regex::new(r"^([a-z0-9_+]([a-z0-9_+.]*[a-z0-9_+])?)@([a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,6})").unwrap();
        let mut email=String::new();
        io::stdin().read_line(&mut email).expect("Fail");
        let email:String=email.trim().parse().expect("Failed");
    
        if domain_regex.is_match(&email){
      
        }
        else
        {
        println!("{} is not valid ", email);
	    break;
        }
	
    
        println!("Enter adress:");
        io::stdin().read_line(&mut adress).expect("Fail");
		let adress:String=adress.trim().parse().expect("Failed");
		
		
		v_srno.push(srno);
		v_name.push(name);

		v_no.push(no);
		
        v_email.push(email);
		
		v_adress.push(adress);
		
		c+=1;
    }

	}
	
	println!(".....contact name details ....");
	println!("{:?} ",v_srno);
	
	println!("{:?} ",v_name);
	
	println!("{:?} ",v_no);
	
	println!("{:?} ",v_email);
	
	println!("{:?} ",v_adress);
	
	
	
    let srno:HashMap<&String,&String>=v_name.iter()
	.zip(v_srno.iter()).collect();
	
	let number:HashMap<&String,&String>=v_name.iter()
	.zip(v_no.iter()).collect();
	
	
    let email:HashMap<&String,&String>=v_name.iter()
	.zip(v_email.iter()).collect();
	
	 let adress:HashMap<&String,&String>=v_name.iter()
	.zip(v_adress.iter()).collect();
	//println!("{:?}{:?} {:?}",contact,email,adress);

	
	
	println!("Which Name to Search....");
	io::stdin().read_line(&mut choice).expect("Fail");
	let choice:String=choice.trim().parse().expect("Fail");

	search(srno,&choice);
	searching(number,&choice);
    find(email,&choice);
	display(adress,&choice);
	
     println!("Which serial number u want to deleted.....");
    io::stdin().read_line(&mut re).expect("Fail");
    let re:usize=re.trim().parse().expect("Fail");

    let _s=re.to_string();
    if v_srno.contains(&_s)
    {
	    let _s= v_srno.remove(re.try_into().unwrap());
        let _s= v_name.remove(re.try_into().unwrap());
        let _s= v_no.remove(re.try_into().unwrap());
        let _s= v_email.remove(re.try_into().unwrap());
        let _s= v_adress.remove(re.try_into().unwrap());
    
    }
      println!("Cotact is deleted......");
	   
	  println!("SRNO: {:?}\n NAME: {:?}\nContact no: {:?}\nEmail_ID: {:?}\nADRESS: {:?}",v_srno,v_name,v_no,v_email,v_adress);
  
	 }
	 
	
	
    
fn search(srno:HashMap<&String,&String>,choice:&String)
{
		for (k,v) in srno
		{
			if k==choice 
			{
				println!("srno: {} ",v);
			}
		}
}
fn searching(number:HashMap<&String,&String>,choice:&String)
{
		for (d,e) in number
		{
			if d==choice 
			{
				println!("number: {} ",e);
			}
		}
}

fn find(email:HashMap<&String,&String>,choice:&String)
{
    for (p,a) in email
	{
        if p==choice 
		{
            println!("email: {} ",a);
        }
    }
}
fn display(adress:HashMap<&String,&String>,choice:&String)
{
    for (s,t) in adress
	{
        if s==choice 
		{
            println!("adress: {} ",t);
        }
    }
}

